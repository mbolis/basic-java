package it.sorint.training.ex1;

public class Main {

    /*
     * Write here the main method. It should print a nice `Hello, World!` message.
     */
}
