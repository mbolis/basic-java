package it.sorint.training.ex2;

public class Main {

    public static void main(String[] args) {

        int x, y, z;
        boolean b;
        
        x = 12;
        y = 10.0;
        z = "15";

        // output whether x is less than z, WITHOUT changing the following line!
        System.out.println(b);
        
        final String greeting = "Hello";
        greeting = "Howdy";

        Counter counter; // create a new instance of Counter
        // output counter's inner counter value.
        // increment counter's value.
        // output incremented value.
    }
}
